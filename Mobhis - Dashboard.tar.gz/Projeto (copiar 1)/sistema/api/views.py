from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.db.models import Count
from .serializers import BikeSerializer
from bike.models import Bike, Cidade


@api_view(['GET'])
def getdata(request):
    bikes = Bike.objects.all()
    serializer = BikeSerializer(bikes, many=True)
    return Response(serializer.data )
