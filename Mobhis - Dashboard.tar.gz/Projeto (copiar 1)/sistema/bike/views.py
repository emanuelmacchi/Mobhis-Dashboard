from django.shortcuts import get_object_or_404, render, redirect
from django.db.models import Count, Q
from django.http import HttpResponseBadRequest, JsonResponse
from django.utils import timezone
from collections import defaultdict
from django.views.decorators.http import require_POST, require_GET
from calendar import monthrange
from datetime import date, datetime
import json
from django.core.serializers.json import DjangoJSONEncoder
from urllib.parse import urlencode
from .filters import BikeFilter, FurtadosFilter
from .models import (Bike,
                    StatusDiario,
                    
                    Cidade,
                    Estação,
                    Notificacao
                    )

from .forms import (BikeForm,
                    CidadeForm,
                    EstaçãoForm,
                    Status_AlterarForm,
                    InfoFurtoForm,
                    )

#pagina Home


def home(request):
    # Configuração inicial
    hoje = timezone.now()
    mes_atual = hoje.month
    ano_atual = hoje.year
    
    # Cidade padrão (você pode definir a lógica para escolher a padrão)
    cidade_padrao = Cidade.objects.first()  # Ou sua lógica para escolher a cidade padrão
    
    # Verifica se precisa redirecionar
    if not request.GET.get('mes_ano') or not request.GET.get('cidade'):
        params = {
            'cidade': request.GET.get('cidade', str(cidade_padrao.id) if cidade_padrao else ''),
            'mes_ano': request.GET.get('mes_ano', f"{ano_atual}-{mes_atual:02}"),
            **request.GET.dict()
        }
        # Remove parâmetros vazios
        params = {k: v for k, v in params.items() if v}
        return redirect(f"{request.path}?{urlencode(params)}")
    
    # Processa parâmetros
    try:
        cidade_id = int(request.GET.get('cidade'))
        ano, mes = map(int, request.GET.get('mes_ano').split('-'))
        
        # Validação
        if not Cidade.objects.filter(id=cidade_id).exists():
            raise ValueError("Cidade inválida")
        if mes < 1 or mes > 12:
            raise ValueError("Mês inválido")
        if ano < 2000 or ano > ano_atual + 1:
            raise ValueError("Ano inválido")
            
    except (ValueError, TypeError, AttributeError):
        # Redireciona com valores padrão se houver erro
        params = {
            'cidade': str(cidade_padrao.id) if cidade_padrao else '',
            'mes_ano': f"{ano_atual}-{mes_atual:02}",
        }
        return redirect(f"{request.path}?{urlencode(params)}")
    
    # Restante da lógica...
    dias_do_mes = monthrange(ano, mes)[1]
    datas = [date(ano, mes, dia) for dia in range(1, dias_do_mes + 1)]
    
    cidades = Cidade.objects.annotate(
        total_bikes=Count('bike'),
        furtadas=Count('bike', filter=Q(bike__status="F"))
    )
    
    bikes = Bike.objects.filter(cidade_id=cidade_id)
    status_map = defaultdict(dict)
    
    for s in StatusDiario.objects.filter(
        bike__in=bikes,
        data__month=mes,
        data__year=ano
    ):
        status_map[s.bike_id][s.data] = s

    context = {
        'hoje': hoje.date(),
        'cidades': cidades,
        'bikes': bikes,
        'datas': datas,
        'status_map': status_map,
        'mes': mes,
        'ano': ano,
        'cidade_selecionada': cidade_id,
    }
    return render(request, 'charts.html', context)
    


@require_POST
def atualizar_status(request):
    try:
        data_json = request.POST.get('status_data')
        if not data_json:
            raise ValueError("Dados não encontrados (É necessario selecionar pelo menos 1 status para ser alterado!)")
            
        status_list = json.loads(data_json)
        hoje = date.today()
        
        for item in status_list:
            bike_id = item.get('bike_id')
            data_str = item.get('data')
            status = item.get('status')

            if not all([bike_id, data_str, status]):
                continue

            data = date.fromisoformat(data_str)
            try:
                bike = Bike.objects.get(id=bike_id)
                
                # Atualiza StatusDiario
                status_obj, created = StatusDiario.objects.update_or_create(
                    bike=bike,
                    data=data,
                    defaults={
                        'status': status,
                        'cidade': bike.cidade
                    }
                )
                
                # Se for status do dia atual, atualiza também o status principal
                if data == hoje:
                    if bike.status != status:
                        bike.status = status
                        bike.motivo = 'MANUAL'  # Ou outro motivo conforme sua lógica
                        bike.save()
                        
            except Bike.DoesNotExist:
                print(f"Bike {bike_id} não encontrada")
                continue
                
        return redirect(request.META.get('HTTP_REFERER', '/'))
        
    except Exception as e:
        print(f"Erro grave: {str(e)}")
        return HttpResponseBadRequest(f"Erro no servidor: {str(e)}")


@require_GET
def api_status_bikes(request):
    # Recebe cidade_id ou nome da cidade
    cidade_id = request.GET.get('cidade_id')
    cidade_nome = request.GET.get('cidade')
    
    if not cidade_id and not cidade_nome:
        return JsonResponse({'error': 'Parâmetro cidade_id ou cidade é obrigatório'}, status=400)
    
    try:
        # Tenta encontrar a cidade por ID ou nome
        if cidade_id:
            cidade = Cidade.objects.get(id=cidade_id)
        else:
            cidade = Cidade.objects.get(nome=cidade_nome)
            
        # Calcula os status das bikes
        status = {
            'presente': Bike.objects.filter(cidade=cidade, status='P').count(),
            'furtada': Bike.objects.filter(cidade=cidade, status='F').count(),
            'ausente': Bike.objects.filter(cidade=cidade, status='A').count(),
            'transito': Bike.objects.filter(cidade=cidade, status='T').count(),
            'manutencao': Bike.objects.filter(cidade=cidade, status='M').count(),
            'desativada': Bike.objects.filter(cidade=cidade, status='D').count(),
        }
        
        return JsonResponse(status)
        
    except Cidade.DoesNotExist:
        return JsonResponse({'error': 'Cidade não encontrada'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


#não sei oq isso faz...
def get_status_por_data(request):
    data_str = request.GET.get('data')
    if not data_str:
        return JsonResponse({}, status=400)
    
    try:
        data = datetime.strptime(data_str, '%Y-%m-%d').date()
        status = {
            str(bike.id): status.status 
            for bike, status in Bike.objects.filter(
                statusdiario__data=data
            ).prefetch_related('statusdiario_set').values_list(
                'id', 'statusdiario__status'
            )
        }
        return JsonResponse(status)
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)





def Desativados(request):
    bikes = Bike.objects.all()    
    bike_filter = BikeFilter(request.GET, queryset=bikes)
    data = {"bikes": bike_filter.qs, "filter": bike_filter}
    return render(request, "desativados.html", data)


#Faz o Template Base carregar os dados das bikes
def Base(request):
    bike = Bike.objects.all()
    data = {'bike': bike}
    return render(request, "base.html", data)



#pagina Furtos
def furtos(request):
    bikes = Bike.objects.all()
    form = BikeForm()
    furtados_filter = FurtadosFilter(request.GET, queryset=bikes)
    data = {"bikes": furtados_filter.qs,"form": form,"filter": furtados_filter}
    return render(request, "furtos.html", data) 


#Alterar Status da Bike Furtos
def AlterarStatus(request, id):
    data = {}
    bike = Bike.objects.get(id=id)
    form = Status_AlterarForm(request.POST or None, instance=bike)
    data['bike'] = bike
    data['form'] = form

    if request.method == 'POST':
        if form.is_valid():
            form.save()
        return redirect('furtos')
    else:
        return render(request, 'alterar_status.html', data)


#Notificaçoes
def Notificacoes(request):
    notificacoes = Notificacao.objects.all().order_by('-data_criacao')
    return render(request, "notificacoes.html", {'notificacoes': notificacoes})

def AtualizarNotificacoes(request):
    if request.method == "POST":
        # Verifica se o modal enviou notificações selecionadas
        notificacoes_selecionadas = request.POST.get('notificacoes_selecionadas', '')
        if notificacoes_selecionadas:
            ids = notificacoes_selecionadas.split(',')
            acao = request.POST.get("acao")

            if ids:
                if acao == "marcar_lidas":
                    Notificacao.objects.filter(id__in=ids).update(lida=True)
                elif acao == "excluir":
                    Notificacao.objects.filter(id__in=ids).delete()
            return redirect("notificacoes")

        # Caso contrário, processa os checkboxes do formulário principal
        notificacoes_ids = request.POST.getlist("notificacoes")
        acao = request.POST.get("acao")

        if notificacoes_ids:
            if acao == "marcar_lidas":
                Notificacao.objects.filter(id__in=notificacoes_ids).update(lida=True)
            elif acao == "excluir":
                Notificacao.objects.filter(id__in=notificacoes_ids).delete()

    return redirect("notificacoes")


#Ver as informações completas da Bike na tabela de Furtos
def Info(request, cidade_id, numero):
    data = {}
    
    try:
        # Busca a bike com a cidade já carregada (mais eficiente)
        bike = get_object_or_404(
            Bike.objects.select_related('cidade'),
            numero=numero,
            cidade__id=cidade_id
        )
        
        # A cidade já está disponível via bike.cidade
        cidade = bike.cidade
        
        # Prepara o formulário
        form = InfoFurtoForm(request.POST or None, instance=bike)
        
        # Prepara os dados para o template
        data.update({
            'bike': bike,
            'form': form,
            'cidade': cidade
        })
        
        if request.method == 'POST':
            if form.is_valid():
                form.save()
                return redirect('home')  # Ou outra URL apropriada
        
        return render(request, 'info_furto.html', data)
        
    except Exception as e:
        return redirect('')  # Ajuste para sua URL de fallback
    
def InfoFurto(request, id):
    data = {}
    bike = Bike.objects.get(id=id)
    form = InfoFurtoForm(request.POST or None, instance=bike)
    data['bike'] = bike
    data['form'] = form

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('furtos')
    else:
        return render(request, 'info_furto.html', data)


#CRUD Bike
def ListaBike(request):
    bikes = Bike.objects.all().order_by('cidade', 'numero')
    form = BikeForm()
    bike_filter = BikeFilter(request.GET, queryset=bikes)
    data = {"bikes": bike_filter.qs,"form": form,"filter": bike_filter}
    return render(request, "lista_bike.html", data) 

def BikeNova(request):
    form = BikeForm(request.POST or None)
    if form.is_valid():
        Bike.motivo = "MANUAL"
        form.save()
        return redirect("lista-bike")
    
def BikeUpdate(request, id):
    data = {}
    bike = Bike.objects.get(id=id)
    form = BikeForm(request.POST or None, instance=bike)
    data['bike'] = bike
    data['form'] = form

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('lista-bike')
    else:
        return render(request, 'update_bike.html', data)
        

def BikeDelete(request, id):
    bike = Bike.objects.get(id=id)
    if request.method == 'POST':
        bike.delete()
        return redirect('lista-bike')
    else:
        return render(request, 'delete_confirm.html', {'obj': bike})


#CRUD Cidade
def ListaCidades(request):
    cidades = Cidade.objects.annotate(num_bikes=Count('bike'))
    #count Conta o numero de bikes por cidade
    form = CidadeForm()
    data = {"cidades": cidades,"form": form,}
    return render(request, "lista_cidades.html", data) 

def CidadeNova(request):
    form = CidadeForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect("lista-cidades")
    
def CidadeUpdate(request, id):
    data = {}
    cidade = Cidade.objects.get(id=id)
    form = CidadeForm(request.POST or None, instance=cidade)
    data['cidade'] = cidade
    data['form'] = form

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('lista-cidades')
    else:
        return render(request, 'update_cidade.html', data)

def CidadeDelete(request, id):
    cidade = Cidade.objects.get(id=id)
    if request.method == 'POST':
        cidade.delete()
        return redirect('lista-cidades')
    else:
        return render(request, 'delete_confirm.html', {'obj': cidade})


#CRUD Estação
def ListaEstações(request):
    estações = Estação.objects.all().order_by('cidade', 'numero')
    form = EstaçãoForm()
    data = {"estações": estações,"form": form}
    return render(request, "lista_estações.html", data) 

def EstaçãoNova(request):
    form = EstaçãoForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect("lista-estações")
    
def EstaçãoUpdate(request, id):
    data = {}
    estação = Estação.objects.get(id=id)
    form = EstaçãoForm(request.POST or None, instance=estação)
    data['estação'] = estação
    data['form'] = form

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('lista-estações')
    else:
        return render(request, 'update_estação.html', data)

def EstaçãoDelete(request, id):
    estação = Estação.objects.get(id=id)
    if request.method == 'POST':
        estação.delete()
        return redirect('lista-estações')
    else:
        return render(request, 'delete_confirm.html', {'obj': estação})





