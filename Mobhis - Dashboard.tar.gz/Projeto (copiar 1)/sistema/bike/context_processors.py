from .models import Notificacao, Cidade

def notificacoes_nao_lidas(request):
    if request.user.is_authenticated:
        # Obtém as notificações não lidas do usuário autenticado
        nao_lidas = Notificacao.objects.filter(lida=False).count()
        return {"notificacoes_nao_lidas": nao_lidas}
    return {"notificacoes_nao_lidas": 0}


def cidades_context(request):
    return {
        'cidades': Cidade.objects.all().order_by('nome')
    }