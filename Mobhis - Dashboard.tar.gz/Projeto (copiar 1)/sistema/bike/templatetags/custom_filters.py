from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    if dictionary is None:
        return {}
    return dictionary.get(key)

@register.filter
def default_dict_if_none(value):
    return value or {}

@register.filter
def dict_get(d, key):
    if isinstance(d, dict):
        return d.get(key)
    return None

@register.filter
def last_before_date(status_dict, date):
    if not status_dict:
        return None
    # Retorna o último status antes da data especificada
    previous_statuses = {k: v for k, v in status_dict.items() if k < date}
    if previous_statuses:
        return max(previous_statuses.items(), key=lambda x: x[0])[1]
    return None