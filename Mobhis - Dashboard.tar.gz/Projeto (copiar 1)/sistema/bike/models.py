from django.db import models
from django.utils.timezone import now


#Cidade em que a Bike se encontra
class Cidade(models.Model):
    nome = models.CharField(max_length=50, unique=True, blank=True, null=True)
    def __str__(self):
        return self.nome


#Estação em que a Bike se encontra
class Estação(models.Model):
    nome = models.CharField(max_length=50, unique=True, blank=True, null=True)
    numero = models.DecimalField(max_digits=5, decimal_places=0, blank=True, null=True)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE, blank=False)
    def __str__(self):
        return ("E") + str(self.numero) + (" - ") + self.nome


#A Bike em si
class Bike(models.Model):

    PRESENTE = "P"
    FURTADA = "F"
    AUSENTE = "A"
    EM_TRÂNSITO = "T"
    EM_MANUTENÇÃO = "M"
    DESATIVADA = "D"
    STATUS_CHOICES = {
        (PRESENTE, "Presente"),
        (FURTADA, "Furtada"),
        (AUSENTE, "Ausente"),
        (EM_TRÂNSITO, "Em Trânsito"),
        (EM_MANUTENÇÃO, "Em Manutenção"),
        (DESATIVADA, "Desativada"),
    }
    MOTIVO_CHOICES = {
        ("MANUAL", "Manual"),
        ("SISTEMA", "Sistema"),
    }

    status = models.CharField(max_length=1, choices=STATUS_CHOICES, default=PRESENTE)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE, blank=False)
    estação = models.ForeignKey(Estação, on_delete=models.CASCADE, blank=True, null=True)
    vaga = models.CharField(max_length=10, blank=True, null=True)
    motivo = models.CharField(max_length=10, choices=MOTIVO_CHOICES, blank=True, null=True, default='MANUAL')
    numero = models.CharField(max_length=100, blank=False) 
    BO = models.BooleanField(max_length=10, blank=True, null=True, default=False)
    horario = models.DateTimeField(blank=True, null=True)
    dados_obtidos_atraves_de_video = models.CharField(max_length=150, blank=True, null=True)
    usuário = models.CharField(max_length=200, blank=True, null=True)
    ultima_alteracao_status = models.DateTimeField(auto_now=True)
    OBS = models.TextField(max_length=500, blank=True, null=True)
    def __str__(self):
        return ("N°") + str(self.numero)

    def save(self, *args, **kwargs):
        if self.pk:  
            bike_antiga = Bike.objects.get(pk=self.pk)
            if bike_antiga.status != self.status:
                self.ultima_alteracao_status = now()  
                if not self.motivo:
                    self.motivo = "SISTEMA"
        super().save(*args, **kwargs) 

        #Esta logica verifica, primeiramente, se a bike sofreu uma alteração no Status.
        #Se sim, o relogio é resetado.
        #Caso contrário, o relogio continua com o mesmo valor.
        #A lógica do relogio é feita no método save() da classe Bike.

    def save(self, *args, **kwargs):
        if self.pk:
            bike_antiga = Bike.objects.get(pk=self.pk)
            if bike_antiga.status != self.status:
                from .models import Notificacao
                Notificacao.objects.create(
                    mensagem=f"A bike N°{self.numero}({self.cidade}) teve seu status alterado de '{bike_antiga.get_status_display()}' para '{self.get_status_display()}'.",
                    estado_anterior=bike_antiga.get_status_display(),
                    estado_atual=self.get_status_display(),
                )
                self.ultima_alteracao_status = now()
        super().save(*args, **kwargs) 

        #Esta logica verifica, primeiramente, se a bike sofreu uma alteração no Status.
        #Se sim, uma notificação é criada.


    def conta_status(self, *args, **kwargs):
        bike = Bike.objects.filter(**args, **kwargs).count()
        return bike


class StatusDiario(models.Model):
    bike = models.ForeignKey(Bike, on_delete=models.CASCADE)
    data = models.DateField()
    status = models.CharField(max_length=1, choices=Bike.STATUS_CHOICES)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.bike.numero} - {self.data} - {self.get_status_display()}"


class Notificacao(models.Model):
    mensagem = models.TextField()
    data_criacao = models.DateTimeField(auto_now_add=True)
    lida = models.BooleanField(default=False)
    estado_anterior = models.CharField(max_length=50, blank=True, null=True)  # Estado anterior da bike
    estado_atual = models.CharField(max_length=50, blank=True, null=True)  # Novo estado da bike

    def __str__(self):
        return f"Notificação em {self.data_criacao}: {self.mensagem}"





