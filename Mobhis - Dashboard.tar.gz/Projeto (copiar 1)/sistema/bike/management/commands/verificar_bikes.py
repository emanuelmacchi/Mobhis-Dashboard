from django.core.management.base import BaseCommand
from django.utils.timezone import now, timedelta
from bike.models import Bike

class Command(BaseCommand):
    help = "Verifica bikes ausentes por mais de 48 horas e altera o status para 'Furtada'"

    def handle(self, *args, **kwargs):
        limite = now() - timedelta(hours=40)
        bikes_ausentes = Bike.objects.filter(status="A", ultima_alteracao_status__lte=limite)

        for bike in bikes_ausentes:
            bike.status = "F"
            bike.motivo = "SISTEMA"
            bike.save()
            self.stdout.write(f"Bike {bike.numero} marcada como 'Furtada'")

            #primeiro, define um limite de 40 horas entre o tempo atual e a ultima alteração de status
            #depois, filtra as bikes que estão ausentes e cuja ultima alteração de status é menor ou igual ao limite
            #se a bike estiver ausente por mais de 40 horas, altera o status para furtada