from django.contrib import admin
from .models import (
    Cidade,
    Estação,
    Bike,
    
)

admin.site.register(Cidade),
admin.site.register(Estação),
admin.site.register(Bike),
