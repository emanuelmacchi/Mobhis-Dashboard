from django import forms
from .models import Cidade, Estação, Bike

class CidadeForm(forms.ModelForm):
    class Meta:
        model = Cidade
        fields = '__all__'

class EstaçãoForm(forms.ModelForm): 
    class Meta:
        model = Estação
        fields = ('numero', 'nome', 'cidade')

class BikeForm(forms.ModelForm):
    class Meta:
        model = Bike
        fields = ('cidade', 'numero', 'estação')

class Status_AlterarForm(forms.ModelForm):
    class Meta:
        model = Bike
        fields = ('status',)

class InfoFurtoForm(forms.ModelForm):
    # Defina os campos personalizados FORA da classe Meta
    BO_CHOICES = [
        (True, 'Sim'),
        (False, 'Não'),
    ]
    
    BO = forms.ChoiceField(
        choices=BO_CHOICES,
        widget=forms.RadioSelect,
        required=False,
        label='BO'
    )
    
    class Meta:
        model = Bike
        fields = ('estação', 'vaga', 'horario', 'dados_obtidos_atraves_de_video', 'BO', 'usuário', 'OBS')
