from datetime import date
from django.core.exceptions import ValidationError

def validate_status_data(item):
    """Valida um item individual de status_data"""
    required_fields = {'bike_id', 'data', 'status'}
    
    # Verifica campos obrigatórios
    if not all(field in item for field in required_fields):
        raise ValidationError("Campos obrigatórios faltando: bike_id, data, status")
    
    # Valida tipos dos campos
    try:
        int(item['bike_id'])
        date.fromisoformat(item['data'])
    except (ValueError, TypeError) as e:
        raise ValidationError(f"Formato inválido: {str(e)}")
    
    # Valida status
    valid_statuses = {'P', 'A', 'M', 'F', 'T', 'D'}
    if item['status'].upper() not in valid_statuses:
        raise ValidationError(f"Status inválido: {item['status']}")

def validate_date_not_future(data_status):
    """Valida que a data não é futura"""
    if data_status > date.today():
        raise ValidationError("Não é possível definir status para datas futuras")