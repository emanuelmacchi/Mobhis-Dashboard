import django_filters
from .models import Bike


class BikeFilter(django_filters.FilterSet):
    class Meta:
        model = Bike
        fields = {
            'numero': ['exact'],
            'cidade': ['exact'],
            'modo': ['exact'],
        }

class FurtadosFilter(django_filters.FilterSet):
    class Meta:
        model = Bike
        fields = {
            'numero': ['exact'],
            'cidade': ['exact'],
            'motivo': ['exact'],
            'BO': ['exact'],
        }