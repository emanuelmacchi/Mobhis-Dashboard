# Core Django
from django.shortcuts import get_object_or_404, render, redirect
from django.http import HttpResponse, JsonResponse
from django.core.exceptions import ValidationError, PermissionDenied
from django.utils import timezone
from django.db.models import Q, Count, Value, IntegerField
from django.db.models.functions import Coalesce
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST, require_GET
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.core.cache import cache
from django.template.loader import render_to_string
from django.core.serializers.json import DjangoJSONEncoder
from django.db import transaction
import json
import traceback
import logging

# Utilitários
from io import BytesIO
from datetime import date, datetime, timedelta
from calendar import monthrange
import json
import logging
from collections import defaultdict
import traceback
from urllib.parse import urlencode

# Excel
import openpyxl
from openpyxl.styles import (
    Font,          
    PatternFill,   )

# Validadores
from .validators import validate_status_data, validate_date_not_future

# Filtros
from .filters import BikeFilter, FurtadosFilter

# Models
from .models import (Bike,
                    StatusDiario,
                    
                    Cidade,
                    Estação,
                    Notificacao
                    )

# Forms
from .forms import (BikeForm,
                    CidadeForm,
                    EstaçãoForm,
                    Status_AlterarForm,
                    InfoFurtoForm,
                    )



#para o sumario
logger = logging.getLogger(__name__)

#pagina Home
def parse_date(date_str):
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        return None


def home(request):
    # Configuração inicial
    hoje = timezone.now()
    mes_atual = hoje.month
    ano_atual = hoje.year

    if not request.GET.get('mes_ano') or not request.GET.get('cidade'):
        cidade_padrao = Cidade.objects.first()
        params = {
            'cidade': request.GET.get('cidade', str(cidade_padrao.id) if cidade_padrao else ''),
            'mes_ano': request.GET.get('mes_ano', f"{ano_atual}-{mes_atual:02}"),
            **{k: v for k, v in request.GET.items() if k not in ['mes_ano', 'cidade']}
        }
        return redirect(f"{request.path}?{urlencode(params)}")

    try:
        cidade_id = int(request.GET.get('cidade'))
        ano, mes = map(int, request.GET.get('mes_ano').split('-'))

        if not Cidade.objects.filter(id=cidade_id).exists():
            raise ValueError("Cidade inválida")
        if mes < 1 or mes > 12:
            raise ValueError("Mês inválido")
        if ano < 2000 or ano > ano_atual + 1:
            raise ValueError("Ano inválido")

    except (ValueError, TypeError, AttributeError):
        cidade_padrao = Cidade.objects.first()
        params = {
            'cidade': str(cidade_padrao.id) if cidade_padrao else '',
            'mes_ano': f"{ano_atual}-{mes_atual:02}",
        }
        return redirect(f"{request.path}?{urlencode(params)}")

    cidades = cache.get_or_set(
        'todas_cidades',
        lambda: list(Cidade.objects.all().only('id', 'nome')),
        60 * 60 * 24
    )

    cache_key = f'bikes_por_cidade_{cidade_id}'
    bikes = cache.get_or_set(
        cache_key,
        lambda: list(Bike.objects.filter(cidade_id=cidade_id)
                     .select_related('cidade', 'estação')
                     .only('id', 'numero', 'cidade__nome', 'estação__nome')
                     .order_by('numero')),
        60 * 15
    )

    dias_do_mes = monthrange(ano, mes)[1]
    datas = [date(ano, mes, dia) for dia in range(1, dias_do_mes + 1)]

    status_map = defaultdict(dict)
    status_diarios = StatusDiario.objects.filter(
        bike__in=[b.id for b in bikes],
        data__month=mes,
        data__year=ano
    ).select_related('bike', 'cidade').only(
        'bike_id', 'data', 'status', 'cidade__nome'
    )

    for s in status_diarios:
        status_map[s.bike_id][s.data] = s

    # Preenche o dia 1 com o último status anterior, se necessário
    dia_1 = date(ano, mes, 1)
    for bike in bikes:
        if dia_1 not in status_map[bike.id]:
            ultimo_status = StatusDiario.objects.filter(
                bike_id=bike.id,
                data__lt=dia_1
            ).order_by('-data').first()
            if ultimo_status:
                status_map[bike.id][dia_1] = ultimo_status

    context = {
        'hoje': hoje.date(),
        'bikes': bikes,
        'datas': datas,
        'status_map': status_map,
        'mes': mes,
        'ano': ano,
        'cidade_selecionada': cidade_id,
        'cidades': cidades,
    }

    return render(request, 'home.html', context)



@require_POST
@csrf_protect
def atualizar_status(request):
    if not request.user.is_authenticated:
        return JsonResponse({'success': False, 'error': 'Autenticação necessária'}, status=401)

    try:
        with transaction.atomic():
            # 1. Parsing e validação inicial
            try:
                raw_data = json.loads(request.body)
                items = []
                validation_errors = []

                if not isinstance(raw_data.get('status_data', []), list):
                    return JsonResponse({'success': False, 'error': 'Formato inválido: status_data deve ser uma lista'}, status=400)

                for idx, item in enumerate(raw_data.get('status_data', [])):
                    try:
                        if not item.get('bike_id'):
                            raise ValueError("ID da bike não fornecido")

                        try:
                            bike_id = int(item['bike_id'])
                        except (ValueError, TypeError):
                            raise ValueError("ID da bike deve ser um número")

                        try:
                            data_status = date.fromisoformat(item['data'])
                        except (ValueError, TypeError):
                            raise ValueError("Data inválida. Use o formato AAAA-MM-DD")

                        status = item.get('status', '').upper()
                        if status not in dict(Bike.Status.choices):
                            raise ValueError(f"Status inválido. Opções válidas: {dict(Bike.Status.choices)}")

                        # ⚠️ Permite alteração do dia 1 mesmo que venha de outro mês
                        # (Validação customizada pode ser feita aqui se necessário)

                        items.append({
                            'bike_id': bike_id,
                            'data': data_status,
                            'status': status,
                            'is_historical': data_status < date.today(),
                            'original_item': item
                        })

                    except Exception as e:
                        validation_errors.append(f"Item {idx + 1}: {str(e)}")
                        continue

                if not items and validation_errors:
                    return JsonResponse({
                        'success': False,
                        'error': 'Nenhum dado válido encontrado',
                        'erros_validacao': validation_errors
                    }, status=400)

            except json.JSONDecodeError:
                return JsonResponse({'success': False, 'error': 'JSON inválido'}, status=400)

            # 2. Busca otimizada das bikes
            bike_ids = {item['bike_id'] for item in items}
            bikes = {
                b.id: b
                for b in Bike.objects.filter(id__in=bike_ids)
                    .select_related('cidade')
                    .only('id', 'numero', 'cidade_id', 'cidade__nome', 'status')
            }

            atualizados = 0
            notifications = []
            cidade_ids = set()
            processing_errors = []
            user_name = request.user.get_full_name() or request.user.username

            for item in items:
                try:
                    bike = bikes.get(item['bike_id'])
                    if not bike:
                        raise Bike.DoesNotExist()

                    old_status = StatusDiario.objects.filter(
                        bike_id=item['bike_id'],
                        data=item['data']
                    ).values_list('status', flat=True).first()

                    if old_status is None:
                        old_status = bike.status

                    old_status_label = dict(Bike.Status.choices).get(old_status) if old_status else 'Sem status'

                    obj, created = StatusDiario.objects.update_or_create(
                        bike_id=item['bike_id'],
                        data=item['data'],
                        defaults={
                            'status': item['status'],
                            'cidade': bike.cidade,
                            'usuario': request.user,
                            'is_historical': item['is_historical']
                        }
                    )

                    if item['data'] == date.today() and bike.status != item['status']:
                        bike.status = item['status']
                        bike.motivo = Bike.Motivo.SISTEMA
                        bike.save()

                    if created or old_status != item['status']:
                        new_status_label = dict(Bike.Status.choices).get(item['status'], item['status'])

                        msg_base = (
                            f"Bike N°{bike.numero} ({bike.cidade.nome} -- {bike.id}) - "
                            f"Status alterado de {old_status_label} para {new_status_label}. "
                            f"Alterações feitas por: <b>{user_name}</b>"
                        )

                        if item['is_historical']:
                            msg_base += f" | Alteração histórica ({item['data'].strftime('%d/%m/%Y')})"

                        notifications.append(
                            Notificacao(
                                mensagem=msg_base,
                                estado_anterior=old_status_label,
                                estado_atual=new_status_label
                            )
                        )

                    atualizados += 1
                    cidade_ids.add(bike.cidade_id)

                except Exception as e:
                    processing_errors.append(f"Bike ID {item['bike_id']}: {str(e)}")
                    continue

            if notifications:
                Notificacao.objects.bulk_create(notifications)

            if cidade_ids:
                cache.delete_many([f'bikes_por_cidade_{cid}' for cid in cidade_ids] + ['todas_cidades'])

            return JsonResponse({
                'success': True,
                'atualizados': atualizados,
                'notificacoes': len(notifications),
                'erros_validacao': validation_errors if validation_errors else None,
                'erros_processamento': processing_errors if processing_errors else None
            })

    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)




#Baixar planilhas relatorios em excel automaticamente (feito por IA):
def export_status_resumo(request):
    # 1. Define a data do relatório
    hoje = date.today()
    ultimo_dia_mes = (date(hoje.year, hoje.month + 1, 1) - timedelta(days=1))
    data_relatorio = min(hoje, ultimo_dia_mes)
    
    # 2. Cria o Excel
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Status Bikes"
    
    # 3. Configurações iniciais
    cabecalho_style = Font(bold=True, size=12)
    cidade_style = Font(bold=True, italic=True, color="0077AA")
    
    # 4. Consulta os dados agrupados por cidade
    cidades = Cidade.objects.annotate(
        total_bikes=Count('bike')
    ).order_by('nome')
    
    linha_atual = 1
    
    for cidade in cidades:
        # 5. Adiciona cabeçalho da cidade
        ws.cell(row=linha_atual, column=1, value=f"{cidade.nome}:").font = cidade_style
        linha_atual += 1
        
        # 6. Adiciona cabeçalhos das colunas
        ws.cell(row=linha_atual, column=1, value="Bike").font = cabecalho_style
        ws.cell(row=linha_atual, column=2, value="Status").font = cabecalho_style
        linha_atual += 1
        
        # 7. Preenche as bikes da cidade
        bikes = Bike.objects.filter(
            cidade=cidade,
            statusdiario__data=data_relatorio
        ).select_related('cidade').order_by('numero')
        
        for bike in bikes:
            ultimo_status = StatusDiario.objects.filter(
                bike=bike,
                data__lte=data_relatorio
            ).order_by('-data').first()
            
            if ultimo_status:
                ws.cell(row=linha_atual, column=1, value=bike.numero)
                ws.cell(row=linha_atual, column=2, value=ultimo_status.get_status_display())
                linha_atual += 1
        
        # 8. Adiciona linha em branco entre cidades
        linha_atual += 1
    
    # 9. Cálculo do resumo (agora funcionando corretamente)
    resumo = StatusDiario.objects.filter(
        data=data_relatorio
    ).values('status').annotate(
        total=Count('status')
    ).order_by('status')
    
    # 10. Adiciona o resumo
    ws.cell(row=linha_atual, column=1, value=f"Dados consolidados para {data_relatorio.strftime('%d/%m/%Y')}:").font = cabecalho_style
    linha_atual += 1
    
    status_map = {
        'P': 'Presentes',
        'A': 'Ausentes',
        'M': 'Em Manutenção',
        'F': 'Furtadas',
        'T': 'Em Trânsito',
        'D': 'Desativadas'
    }
    
    for item in resumo:
        ws.cell(row=linha_atual, column=1, value=status_map.get(item['status']))
        ws.cell(row=linha_atual, column=2, value=item['total'])
        linha_atual += 1
    
    # 11. Ajusta largura das colunas
    ws.column_dimensions['A'].width = 25
    ws.column_dimensions['B'].width = 20
    
    # 12. Gera o arquivo
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    
    response = HttpResponse(
        buffer.getvalue(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    filename = f"relatorio_bikes_{data_relatorio.strftime('%Y%m')}.xlsx"
    response['Content-Disposition'] = f'attachment; filename={filename}'
    
    return response


@require_GET
def api_status_bikes(request):
    # Recebe cidade_id ou nome da cidade
    cidade_id = request.GET.get('cidade_id')
    cidade_nome = request.GET.get('cidade')
    
    if not cidade_id and not cidade_nome:
        return JsonResponse({'error': 'Parâmetro cidade_id ou cidade é obrigatório'}, status=400)
    
    try:
        # Tenta encontrar a cidade por ID ou nome
        if cidade_id:
            cidade = Cidade.objects.get(id=cidade_id)
        else:
            cidade = Cidade.objects.get(nome=cidade_nome)
            
        # Calcula os status das bikes
        status = {
            'presente': Bike.objects.filter(cidade=cidade, status='P').count(),
            'furtada': Bike.objects.filter(cidade=cidade, status='F').count(),
            'ausente': Bike.objects.filter(cidade=cidade, status='A').count(),
            'transito': Bike.objects.filter(cidade=cidade, status='T').count(),
            'manutencao': Bike.objects.filter(cidade=cidade, status='M').count(),
            'desativada': Bike.objects.filter(cidade=cidade, status='D').count(),
        }
        
        return JsonResponse(status)
        
    except Cidade.DoesNotExist:
        return JsonResponse({'error': 'Cidade não encontrada'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


#não sei oq isso faz...
def get_status_por_data(request):
    data_str = request.GET.get('data')
    if not data_str:
        return JsonResponse({}, status=400)
    
    try:
        data = datetime.strptime(data_str, '%Y-%m-%d').date()
        status = {
            str(bike.id): status.status 
            for bike, status in Bike.objects.filter(
                statusdiario__data=data
            ).prefetch_related('statusdiario_set').values_list(
                'id', 'statusdiario__status'
            )
        }
        return JsonResponse(status)
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


def Sumario(request):
    """
    View principal do sumário que trata tanto requisições normais quanto AJAX,
    com ou sem filtro por período de datas.
    """
    try:
        # Dados fixos do parque inicial (poderia ser modelado no banco)
        PARQUE_INICIAL = {
            "Cascavel, PR": {'adulto': 58, 'infantil': 12},
            "Passo Fundo, RS": {'adulto': 80, 'infantil': 0},
            "Sorocaba, SP": {'adulto': 165, 'infantil': 45},
        }

        # 1. Processamento dos parâmetros de data
        data_inicial, data_final = processar_parametros_data(request)

        # 2. Construção dos filtros dinâmicos
        base_filter = Q()
        if data_inicial and data_final:
            base_filter &= Q(bike__data_furto__range=(data_inicial, data_final))

        # 3. Query otimizada com Coalesce para evitar valores None
        cidades = Cidade.objects.annotate(
            total_bikes=Count('bike', filter=base_filter),
            furtadas_adulto=Coalesce(
                Count('bike', filter=base_filter & Q(bike__status="F", bike__modo="ADULTO")),
                Value(0),
                output_field=IntegerField()
            ),
            furtadas_infantil=Coalesce(
                Count('bike', filter=base_filter & Q(bike__status="F", bike__modo="INFANTIL")),
                Value(0),
                output_field=IntegerField()
            ),
            parque_adulto=Coalesce(
                Count('bike', filter=base_filter & Q(bike__modo="ADULTO")),
                Value(0)
            ) - Coalesce(
                Count('bike', filter=base_filter & Q(bike__status="F", bike__modo="ADULTO")),
                Value(0)
            ),
            parque_infantil=Coalesce(
                Count('bike', filter=base_filter & Q(bike__modo="INFANTIL")),
                Value(0)
            ) - Coalesce(
                Count('bike', filter=base_filter & Q(bike__status="F", bike__modo="INFANTIL")),
                Value(0)
            )
        ).order_by('nome')

        # 4. Cálculo dos totais
        totais = {
            'parque_inicial_adulto': sum(c['adulto'] for c in PARQUE_INICIAL.values()),
            'parque_inicial_infantil': sum(c['infantil'] for c in PARQUE_INICIAL.values()),
            'furtadas_adulto': sum(c.furtadas_adulto for c in cidades),
            'furtadas_infantil': sum(c.furtadas_infantil for c in cidades),
            'parque_adulto': sum(c.parque_adulto for c in cidades),
            'parque_infantil': sum(c.parque_infantil for c in cidades),
        }
        totais['total_parque'] = totais['parque_adulto'] + totais['parque_infantil']

        # 5. Preparação do contexto
        context = {
            'cidades': cidades,
            'parque_inicial': {k: v['adulto'] for k, v in PARQUE_INICIAL.items()},
            'parque_inicial2': {k: v['infantil'] for k, v in PARQUE_INICIAL.items()},
            **totais,
            'data_inicial': data_inicial.strftime('%Y-%m-%d') if data_inicial else None,
            'data_final': data_final.strftime('%Y-%m-%d') if data_final else None,
        }

        # 6. Resposta para AJAX ou renderização normal
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return responder_ajax(request, context)
            
        return render(request, "charts.html", context)

    except Exception as e:
        logger.error(f"Erro no sumário: {str(e)}", exc_info=True)
        return responder_erro(request, e)


def processar_parametros_data(request):
    """Processa e valida os parâmetros de data da requisição"""
    data_inicial = request.GET.get('data_inicial')
    data_final = request.GET.get('data_final')
    
    if not data_inicial or not data_final:
        return None, None
        
    try:
        return (
            datetime.strptime(data_inicial, '%Y-%m-%d').date(),
            datetime.strptime(data_final, '%Y-%m-%d').date()
        )
    except ValueError as e:
        logger.warning(f"Formato de data inválido: {data_inicial} ou {data_final}")
        return None, None


def responder_ajax(request, context):
    """Gera a resposta JSON para requisições AJAX"""
    try:
        return JsonResponse({
            'status': 'success',
            'tbody': render_to_string('partials/table_body.html', context),
            'tfoot': render_to_string('partials/table_footer.html', context),
            'data_inicial': context.get('data_inicial'),
            'data_final': context.get('data_final')
        })
    except Exception as e:
        logger.error(f"Erro ao renderizar templates: {str(e)}")
        return JsonResponse({
            'status': 'error',
            'message': 'Erro ao gerar tabela'
        }, status=500)


def responder_erro(request, exception):
    """Gera resposta adequada para erros"""
    error_message = str(exception)
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'status': 'error',
            'message': error_message
        }, status=500)
        
    return render(request, "charts.html", {
        'error': error_message,
        'cidades': [],
        'parque_inicial': {},
        'parque_inicial2': {},
        'total_parque_inicial': 0,
        'total_parque_inicial2': 0,
        'total_furtadas_adulto': 0,
        'total_furtadas_infantil': 0,
        'total_parque_adulto': 0,
        'total_parque_infantil': 0,
        'total_parque': 0
    })


def Desativados(request):
    bikes = Bike.objects.all()    
    bike_filter = BikeFilter(request.GET, queryset=bikes)
    data = {"bikes": bike_filter.qs, "filter": bike_filter}
    return render(request, "desativados.html", data)


#Faz o Template Base carregar os dados das bikes
def Base(request):
    bike = Bike.objects.all()
    data = {'bike': bike}
    return render(request, "base.html", data)


#pagina Furtos
def furtos(request):
    bikes = Bike.objects.all()
    form = BikeForm()
    furtados_filter = FurtadosFilter(request.GET, queryset=bikes)
    data = {"bikes": furtados_filter.qs,"form": form,"filter": furtados_filter}
    return render(request, "furtos.html", data) 


#Notificaçoes
def Notificacoes(request):
    notificacoes = Notificacao.objects.all().order_by('-data_criacao')
    return render(request, "notificacoes.html", {'notificacoes': notificacoes})


def AtualizarNotificacoes(request):
    if request.method == "POST":
        # Verifica se o modal enviou notificações selecionadas
        notificacoes_selecionadas = request.POST.get('notificacoes_selecionadas', '')
        if notificacoes_selecionadas:
            ids = notificacoes_selecionadas.split(',')
            acao = request.POST.get("acao")

            if ids:
                if acao == "marcar_lidas":
                    Notificacao.objects.filter(id__in=ids).update(lida=True)
                elif acao == "excluir":
                    Notificacao.objects.filter(id__in=ids).delete()
            return redirect("notificacoes")

        # Caso contrário, processa os checkboxes do formulário principal
        notificacoes_ids = request.POST.getlist("notificacoes")
        acao = request.POST.get("acao")

        if notificacoes_ids:
            if acao == "marcar_lidas":
                Notificacao.objects.filter(id__in=notificacoes_ids).update(lida=True)
            elif acao == "excluir":
                Notificacao.objects.filter(id__in=notificacoes_ids).delete()

    return redirect("notificacoes")


#Ver as informações completas da Bike na tabela de Furtos
def Info(request, cidade_id, numero):
    data = {}
    
    try:
        # Busca a bike com a cidade já carregada (mais eficiente)
        bike = get_object_or_404(
            Bike.objects.select_related('cidade'),
            numero=numero,
            cidade__id=cidade_id
        )
        
        # A cidade já está disponível via bike.cidade
        cidade = bike.cidade
        
        # Prepara o formulário
        form = InfoFurtoForm(request.POST or None, instance=bike)
        
        # Prepara os dados para o template
        data.update({
            'bike': bike,
            'form': form,
            'cidade': cidade
        })
        
        if request.method == 'POST':
            if form.is_valid():
                form.save()
                return redirect('home')  # Ou outra URL apropriada
        
        return render(request, 'info_furto.html', data)
        
    except Exception as e:
        return redirect('')  # Ajuste para sua URL de fallback
    

def InfoFurto(request, id):
    data = {}
    bike = Bike.objects.get(id=id)
    form = InfoFurtoForm(request.POST or None, instance=bike)
    data['bike'] = bike
    data['form'] = form

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('furtos')
    else:
        return render(request, 'info_furto.html', data)


#CRUD Bike
def ListaBike(request):
    bikes = Bike.objects.all().order_by('cidade', 'numero')
    form = BikeForm()
    bike_filter = BikeFilter(request.GET, queryset=bikes)
    data = {"bikes": bike_filter.qs,"form": form,"filter": bike_filter}
    return render(request, "lista_bike.html", data) 

def BikeNova(request):
    form = BikeForm(request.POST or None)
    if form.is_valid():
        Bike.motivo = "MANUAL"
        form.save()
        return redirect("lista-bike")
    
def BikeUpdate(request, id):
    data = {}
    bike = Bike.objects.get(id=id)
    form = BikeForm(request.POST or None, instance=bike)
    data['bike'] = bike
    data['form'] = form

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('lista-bike')
    else:
        return render(request, 'update_bike.html', data)
        
def BikeDelete(request, id):
    bike = Bike.objects.get(id=id)
    if request.method == 'POST':
        bike.delete()
        return redirect('lista-bike')
    else:
        return render(request, 'delete_confirm.html', {'obj': bike})


#CRUD Cidade
def ListaCidades(request):
    cidades = Cidade.objects.annotate(num_bikes=Count('bike'))
    #count Conta o numero de bikes por cidade
    form = CidadeForm()
    data = {"cidades": cidades,"form": form,}
    return render(request, "lista_cidades.html", data) 

def CidadeNova(request):
    form = CidadeForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect("lista-cidades")
    
def CidadeUpdate(request, id):
    data = {}
    cidade = Cidade.objects.get(id=id)
    form = CidadeForm(request.POST or None, instance=cidade)
    data['cidade'] = cidade
    data['form'] = form

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('lista-cidades')
    else:
        return render(request, 'update_cidade.html', data)

def CidadeDelete(request, id):
    cidade = Cidade.objects.get(id=id)
    if request.method == 'POST':
        cidade.delete()
        return redirect('lista-cidades')
    else:
        return render(request, 'delete_confirm.html', {'obj': cidade})


#CRUD Estação
def ListaEstações(request):
    estações = Estação.objects.all().order_by('cidade', 'numero')
    form = EstaçãoForm()
    data = {"estações": estações,"form": form}
    return render(request, "lista_estações.html", data) 

def EstaçãoNova(request):
    form = EstaçãoForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect("lista-estações")
    
def EstaçãoUpdate(request, id):
    data = {}
    estação = Estação.objects.get(id=id)
    form = EstaçãoForm(request.POST or None, instance=estação)
    data['estação'] = estação
    data['form'] = form

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('lista-estações')
    else:
        return render(request, 'update_estação.html', data)

def EstaçãoDelete(request, id):
    estação = Estação.objects.get(id=id)
    if request.method == 'POST':
        estação.delete()
        return redirect('lista-estações')
    else:
        return render(request, 'delete_confirm.html', {'obj': estação})





