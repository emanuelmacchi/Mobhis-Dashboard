from django.contrib import admin
from .models import (
    Cidade,
    Estação,
    Bike,
    StatusDiario,
)

admin.site.register(Cidade),
admin.site.register(Estação),
admin.site.register(Bike),
admin.site.register(StatusDiario),
