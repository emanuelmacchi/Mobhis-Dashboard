from django.urls import path, re_path
from django.contrib import admin
from .views import (home,
                    atualizar_status,
                    api_status_bikes,
                    export_status_resumo,

                    Sumario,

                    Desativados,

                    furtos,
                    InfoFurto,
                    Info, 
                    
                    ListaBike,
                    BikeNova,
                    BikeUpdate,
                    BikeDelete,

                    ListaCidades,
                    CidadeNova,
                    CidadeUpdate,
                    CidadeDelete,

                    ListaEstações,
                    EstaçãoNova,
                    EstaçãoUpdate,
                    EstaçãoDelete,

                    Notificacoes,
                    AtualizarNotificacoes
                    )


urlpatterns = [
    #Home
    path("", home, name="home"),
    path('atualizar_status/', atualizar_status, name='atualizar_status'),
    path('api/bikes/status/', api_status_bikes, name='api_status_bikes'),
    path('export-status/', export_status_resumo, name='export_status'),

    #sumário
    path('sumario/', Sumario, name='sumario'),

    #admin
    path('admin/', admin.site.urls, name="admin"),

    #desativadas
    path("desativados/", Desativados, name="desativados"),

    #Furtos
    path("furtos", furtos, name="furtos"),
    re_path(r'^furtos/info/(?P<id>\d+)/$', InfoFurto, name='info-furto'),
    re_path(r'^info/(?P<cidade_id>\d+)/(?P<numero>\w+)/$', Info, name='info'),

    #Notificações
    path("notificacoes", Notificacoes, name="notificacoes"),
    path("notificacoes/atualizar", AtualizarNotificacoes, name="atualizar-notificacoes"),

    #CRUD Bike
    path("lista-bike", ListaBike, name="lista-bike"),
    path("bike-novo", BikeNova, name="bike-novo"),
    re_path(r'^lista-bike/update/(?P<id>\d+)/$', BikeUpdate, name='bike-update'),
    re_path(r'^lista-bike/delete/(?P<id>\d+)/$', BikeDelete, name='bike-delete'),

    #CRUD Cidade
    path("lista-cidades", ListaCidades, name="lista-cidades"),
    path("cidade-novo", CidadeNova, name="cidade-nova"),
    re_path(r'^lista-cidades/update/(?P<id>\d+)/$', CidadeUpdate, name='cidade-update'),
    re_path(r'^lista-cidades/delete/(?P<id>\d+)/$', CidadeDelete, name='cidade-delete'),

    #CRUD Estação
    path("lista-estações", ListaEstações, name="lista-estações"),
    path("estação-novo", EstaçãoNova, name="estação-nova"),
    re_path(r'^lista-estações/update/(?P<id>\d+)/$', EstaçãoUpdate, name='estação-update'),
    re_path(r'^lista-estações/delete/(?P<id>\d+)/$', EstaçãoDelete, name='estação-delete'),

]