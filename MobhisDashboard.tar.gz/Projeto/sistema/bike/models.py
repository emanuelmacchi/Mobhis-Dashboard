from django.db import models
from django.utils.timezone import now
from django.conf import settings

#Cidade em que a Bike se encontra
class Cidade(models.Model):
    nome = models.CharField(max_length=50, unique=True, blank=True, null=True)
    def __str__(self):
        return self.nome


#Estação em que a Bike se encontra
class Estação(models.Model):
    nome = models.CharField(max_length=50, unique=True, blank=True, null=True)
    numero = models.DecimalField(max_digits=5, decimal_places=0, blank=True, null=True)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE, blank=False)
    def __str__(self):
        return ("E") + str(self.numero) + (" - ") + self.nome


#A Bike em si
class Bike(models.Model):
    class Status(models.TextChoices):
        PRESENTE = 'P', 'Presente'
        FURTADA = 'F', 'Furtada'
        AUSENTE = 'A', 'Ausente'
        TRANSITO = 'T', 'Em Trânsito'
        MANUTENCAO = 'M', 'Em Manutenção'
        DESATIVADA = 'D', 'Desativada'

    class Modo(models.TextChoices):
        ADULTO = 'ADULTO', 'Adulto'
        INFANTIL = 'INFANTIL', 'Infantil'

    class Motivo(models.TextChoices):
        MANUAL = 'MANUAL', 'Manual'
        SISTEMA = 'SISTEMA', 'Sistema'

    modo = models.CharField(
        max_length=10,
        choices=Modo.choices,
        default=Modo.ADULTO
    )
    status = models.CharField(
        max_length=1,
        choices=Status.choices,
        default=Status.PRESENTE
    )
    cidade = models.ForeignKey(Cidade, on_delete=models.PROTECT)
    estação = models.ForeignKey(
        Estação,
        on_delete=models.SET_NULL,
        blank=True,
        null=True
    )
    vaga = models.CharField(max_length=10, blank=True, null=True)
    motivo = models.CharField(
        max_length=10,
        choices=Motivo.choices,
        blank=True,
        null=True,
        default=Motivo.MANUAL
    )
    numero = models.CharField(max_length=100, unique=False)
    BO = models.BooleanField(default=False)
    horario = models.DateTimeField(blank=True, null=True)
    dados_obtidos_atraves_de_video = models.CharField(
        max_length=150,
        blank=True,
        null=True
    )
    usuário = models.CharField(max_length=200, blank=True, null=True)
    ultima_alteracao_status = models.DateTimeField(auto_now=True)
    OBS = models.TextField(max_length=500, blank=True, null=True)

    def __str__(self):
        return f"N°{self.numero}"

    def save(self, *args, **kwargs):
        if self.pk:  # Se é uma atualização
            bike_antiga = Bike.objects.get(pk=self.pk)
            if bike_antiga.status != self.status:
                self.ultima_alteracao_status = now()
                if not self.motivo:
                    self.motivo = self.Motivo.SISTEMA
        
        super().save(*args, **kwargs)

    class Meta:
        verbose_name = "Bicicleta"
        verbose_name_plural = "Bicicletas"
        ordering = ['numero']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['cidade', 'status']),
        ]

class StatusDiario(models.Model):
    bike = models.ForeignKey(Bike, on_delete=models.CASCADE)
    data = models.DateField()
    status = models.CharField(max_length=1, choices=Bike.Status.choices)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE)
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    is_historical = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.bike.numero} - {self.data} - {self.get_status_display()}"

    class Meta:
        verbose_name = "Status Diário"
        verbose_name_plural = "Status Diários"
        ordering = ['-data']
        constraints = [
            models.UniqueConstraint(
                fields=['bike', 'data'],
                name='status_unico_por_bike_data'
            )
        ]
        indexes = [
            models.Index(fields=['bike', 'data']),
            models.Index(fields=['data']),
            models.Index(fields=['status']),
        ]

class Notificacao(models.Model):
    mensagem = models.TextField()
    data_criacao = models.DateTimeField(auto_now_add=True)
    lida = models.BooleanField(default=False)
    estado_anterior = models.CharField(max_length=50, blank=True, null=True)
    estado_atual = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return f"Notificação em {self.data_criacao}: {self.mensagem[:50]}..."

    class Meta:
        verbose_name = "Notificação"
        verbose_name_plural = "Notificações"
        ordering = ['-data_criacao']





