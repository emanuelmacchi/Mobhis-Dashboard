from django.shortcuts import render
from django.contrib.auth.views import LoginView, LogoutView
from django.views.generic.edit import FormView
from django.contrib.auth import login
from .forms import RegistroUsuarioForm


class Login(LoginView):
    template_name = 'login.html'
    next_page = '/'

class Logout(LogoutView):
    next_page = '/'  

class Registro(FormView):
    template_name = 'registrar.html'
    form_class = RegistroUsuarioForm
    success_url = "/"

    def form_valid(self, form):
        user = form.save(commit=False)
        user.is_superuser = True
        user.is_staff = True  
        user.save()  
        login(self.request, user)
        return super().form_valid(form)